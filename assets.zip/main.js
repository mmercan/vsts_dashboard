VSS.init({
  explicitNotifyLoaded: false,
  usePlatformScripts: false,
  usePlatformStyles: false
});
